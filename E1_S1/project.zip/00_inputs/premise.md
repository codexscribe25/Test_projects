# Premise — The Silent Ferry

A night ferry makes an unscheduled stop at a dark pier; a lone passenger discovers the captain cannot see or hear the pier at all.
