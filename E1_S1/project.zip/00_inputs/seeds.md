# Episode Seeds (Lore-free)

**Seed 01 — The Silent Ferry**

A night ferry makes an unscheduled stop at a dark pier; a lone passenger discovers the captain cannot see or hear the pier at all.

**Seed 02 — Borrowed Tomorrow**

A courier receives a package from their future self with strict instructions: deliver it unopened—or forfeit someone you love.

**Seed 03 — Fault Line Diner**

After a small quake, a roadside diner’s back door opens to a landscape that isn’t on any map.

**Seed 04 — Ghost Frequency**

A pirate radio DJ picks up a broadcast pleading for help from a city that officially doesn’t exist.

**Seed 05 — The Third Key**

A locksmith is hired to open a safe that requires a key no one admits to owning.

**Seed 06 — Ash in the Rain**

Rain begins to fall as fine gray ash; emergency crews respond, but the ash isn’t from any fire.

**Seed 07 — Last Train, First Stop**

The final train of the night stops between stations to let off a single passenger who wasn’t on board a moment ago.

**Seed 08 — Ink Debt**

A struggling illustrator signs a ‘muse contract’ and wakes to find their sketches altering the real world.

**Seed 09 — Closed for Inventory**

A big-box store locks its doors for overnight inventory; by morning, the aisles don’t add up to the same building.

**Seed 10 — Two Minutes Missing**

An entire town loses two minutes of time at once; traffic cameras show everyone standing perfectly still—except one person.
