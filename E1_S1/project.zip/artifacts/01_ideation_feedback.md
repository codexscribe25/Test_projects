Round: R1
Reviewer: [name]
Timestamp: [ISO]

General:
- What I liked:
- What needs change (be specific: tone, stakes, POV, avoid X):

Per-candidate:
- C01: Accept / Refine / Discard — note:
- C02: Accept / Refine / Discard — note:
...
Priority next action: [accept C02] or [refine round with constraints]
