# Validation Report — 20250904T233716Z
Draft: /mnt/data/workspace_project/10_drafts/episode1_v1_20250904T232522Z.md
Generated: 2025-09-04T23:37:16.397847Z

## Summary
- Word count: 1814
- Sentence count: 108
- Average sentence length: 16.8
- Validator pass rate: 0.6 (3/5)

## Validator details

### Banned terms
- Found: ['manifest', 'memory']

### Tone
- tone_score (proxy 0-1): 0.0 (pos 1, neg 12)

### Style
- avg_sentence_length: 16.8, long_sentence_fraction: 0.019

### Continuity (beats presence)

- Beat: The Job Drops: forged manifest, midnight private auction at warlord Karo's fortified warehouse. — Found: True
- Beat: Fortified Routine, Human Unknowns: rooftop entry, thermal sweeps, a humming child in the loading bay. — Found: True
- Beat: Choice & Cost: grab the reliquary and escape, or stall to free innocents and risk capture. — Found: True

Beats order OK: True


## Recommendations

- Remove or replace banned/system tokens found in the draft.
- Overall pass rate below 0.8 — consider a rewrite or targeted fixes.
