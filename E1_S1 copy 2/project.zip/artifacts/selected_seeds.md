---
title: "Selected Seeds — 02_E1_S1"
ticket: "02_E1_S1-select-refs.yml"
generated: "2025-09-04T20:47:45.128938Z"
select_count_requested: 5
---

## Selected Seeds (ranked)

**1.** Rain begins to fall as fine gray ash; emergency crews respond, but the ash isn’t from any fire.  
_Source: workspace/00_inputs/seeds.md — Scores: hook 84, clarity 85, tone 91, novelty 89, avg 87.25_

**2.** A baker’s new yeast ferments time into the crust: eat yesterday’s loaf to recall a day’s taste, but snacks age the eater's patience.  
_Source: fresh_seeds_10.txt — Scores: hook 63, clarity 98, tone 97, novelty 69, avg 81.75_

**3.** **Seed 01 — The Silent Ferry**  
_Source: workspace/00_inputs/seeds.md — Scores: hook 71, clarity 84, tone 94, novelty 73, avg 80.5_

**4.** A baker’s new yeast ferments time into the crust: eat yesterday’s loaf to recall a day’s taste, but snacks age the eater’s patience.  
_Source: fresh_seeds_10.txt — Scores: hook 97, clarity 60, tone 67, novelty 93, avg 79.25_

**5.** Midnight warehouse extraction: steal the auctioned target from a fortified warehouse under warlord guards.  
_Source: action_seeds_10.txt — Scores: hook 65, clarity 95, tone 72, novelty 80, avg 78.0_
