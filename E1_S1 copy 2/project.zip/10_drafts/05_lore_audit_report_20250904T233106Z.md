# Lore Audit Report — 20250904T233106Z
Draft: /mnt/data/workspace_project/10_drafts/episode1_v1_20250904T232522Z.md
Generated: 2025-09-04T23:31:06.882967Z

## Summary
- Banned terms found: 2
  - Terms: manifest, memory
- Proper-noun mentions (Ilya/Marlo/Sera/Kito/Karo): {'Ilya': 25, 'Marlo': 12, 'Sera': 2, 'Kito': 2, 'Karo': 0}
- Beats presence:
  - The Job Drops: forged manifest, midnight private auction at warlord Karo's forti ... Found: True  at pos 325
  - Fortified Routine, Human Unknowns: rooftop entry, thermal sweeps, a humming chil ... Found: True  at pos 1320
  - Choice & Cost: grab the reliquary and escape, or stall to free innocents and ris ... Found: True  at pos 2224
- Beats order OK: True
- Simple contradictions flagged: 0
- Heavy worldbuilding tokens found: []

## Notes and Recommendations
- Remove or replace banned/system tokens (these leak internal system terms).

-- End of report --