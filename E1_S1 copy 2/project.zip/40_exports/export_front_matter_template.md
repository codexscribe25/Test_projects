---
title: "Episode 1 — <working title>"
project_id: "E1_S1"
type: "episode"
year: "GEN01"
location: "—"
wordcount: 0
canonical_status: "candidate"
provenance:
  sources: []
validators:
  tone_guard: pending
  canon_gate: pending
  contradiction_scan: pending
  citation_map: pending
  continuity_check: n/a
---

# Episode 1
