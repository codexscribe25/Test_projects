# PromptCORE placeholder
This folder serves as a visible placeholder to show the project's virtual CORE mapping.
Real prompt files live at: core_storage/prompts (see core_map.yml).
Do not duplicate content here — use the mapping ticket to locate actual files.
