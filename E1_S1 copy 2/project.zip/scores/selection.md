# Selection — Hybrid (Orig+Genre)

Generated: 2025-09-04T21:42:56.646873Z

## 1. Rain begins to fall as fine gray ash; emergency crews respond, but the ash isn’t from any fire.
- Source: /mnt/data/workspace_project/artifacts/selection_report.json
- Chosen from: Originality
- Scores: Originality 80.75, GenreMarket 69.7
- Components: hook 84, clarity 85, tone 91, novelty 63, genrefit 56, producibility 34

## 2. **Seed 02 — Borrowed Tomorrow**
- Source: /mnt/data/workspace_project/00_inputs/seeds.md
- Chosen from: Originality
- Scores: Originality 80.75, GenreMarket 65.2
- Components: hook 76, clarity 66, tone 88, novelty 93, genrefit 50, producibility 43

## 3. A baker’s new yeast ferments time into the crust: eat yesterday’s loaf to recall a day’s taste, but snacks age the eater's patience.
- Source: /mnt/data/workspace_project/artifacts/selection_report.json
- Chosen from: GenreMarket
- Scores: Originality 76.75, GenreMarket 71.0
- Components: hook 63, clarity 98, tone 97, novelty 49, genrefit 50, producibility 62

## 4. Midnight warehouse extraction: steal the auctioned target from a fortified warehouse under warlord guards.
- Source: /mnt/data/workspace_project/artifacts/selection_report.json
- Chosen from: GenreMarket
- Scores: Originality 73.0, GenreMarket 70.75
- Components: hook 65, clarity 95, tone 72, novelty 60, genrefit 62, producibility 63

## 5. **Seed 01 — The Silent Ferry**
- Source: /mnt/data/workspace_project/artifacts/selection_report.json
- Chosen from: Combined
- Scores: Originality 77.25, GenreMarket 68.4
- Components: hook 71, clarity 84, tone 94, novelty 60, genrefit 50, producibility 52
