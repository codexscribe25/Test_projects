# Leaderboard — OriginalityScore
Generated: 2025-09-04T21:42:56.646194Z

**1.** Rain begins to fall as fine gray ash; emergency crews respond, but the ash isn’t from any fire.  
_Source: /mnt/data/workspace_project/artifacts/selection_report.json — Originality 80.75, GenreMarket 69.7_

**2.** **Seed 02 — Borrowed Tomorrow**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 80.75, GenreMarket 65.2_

**3.** **Seed 07 — Last Train, First Stop**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 77.5, GenreMarket 65.2_

**4.** **Seed 01 — The Silent Ferry**  
_Source: /mnt/data/workspace_project/artifacts/selection_report.json — Originality 77.25, GenreMarket 68.4_

**5.** A baker’s new yeast ferments time into the crust: eat yesterday’s loaf to recall a day’s taste, but snacks age the eater's patience.  
_Source: /mnt/data/workspace_project/artifacts/selection_report.json — Originality 76.75, GenreMarket 71.0_

**6.** Midnight warehouse extraction: steal the auctioned target from a fortified warehouse under warlord guards.  
_Source: /mnt/data/workspace_project/artifacts/selection_report.json — Originality 73.0, GenreMarket 70.75_

**7.** **Seed 04 — Ghost Frequency**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 73.0, GenreMarket 62.1_

**8.** A night ferry makes an unscheduled stop at a dark pier; a lone passenger discovers the captain cannot see or hear the pier at all.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 72.0, GenreMarket 61.75_

**9.** After a small quake, a roadside diner’s back door opens to a landscape that isn’t on any map.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 67.25, GenreMarket 57.7_

**10.** A locksmith is hired to open a safe that requires a key no one admits to owning.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 67.25, GenreMarket 62.6_

**11.** A baker’s new yeast ferments time into the crust: eat yesterday’s loaf to recall a day’s taste, but snacks age the eater’s patience.  
_Source: /mnt/data/workspace_project/artifacts/selection_report.json — Originality 66.25, GenreMarket 62.45_

**12.** **Seed 05 — The Third Key**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 65.75, GenreMarket 55.4_

**13.** The final train of the night stops between stations to let off a single passenger who wasn’t on board a moment ago.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 64.5, GenreMarket 55.3_

**14.** **Seed 10 — Two Minutes Missing**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 60.5, GenreMarket 58.6_

**15.** A struggling illustrator signs a ‘muse contract’ and wakes to find their sketches altering the real world.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 60.0, GenreMarket 62.45_

**16.** # Episode Seeds (Lore-free)  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 58.5, GenreMarket 58.45_

**17.** **Seed 08 — Ink Debt**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 55.0, GenreMarket 53.4_

**18.** **Seed 06 — Ash in the Rain**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 53.5, GenreMarket 46.55_

**19.** A pirate radio DJ picks up a broadcast pleading for help from a city that officially doesn’t exist.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 51.25, GenreMarket 53.75_

**20.** **Seed 03 — Fault Line Diner**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 50.0, GenreMarket 50.55_

**21.** An entire town loses two minutes of time at once; traffic cameras show everyone standing perfectly still—except one person.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 46.25, GenreMarket 48.05_

**22.** A big-box store locks its doors for overnight inventory; by morning, the aisles don’t add up to the same building.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 40.5, GenreMarket 42.85_

**23.** A courier receives a package from their future self with strict instructions: deliver it unopened—or forfeit someone you love.  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 40.25, GenreMarket 43.6_

**24.** **Seed 09 — Closed for Inventory**  
_Source: /mnt/data/workspace_project/00_inputs/seeds.md — Originality 38.5, GenreMarket 43.15_
